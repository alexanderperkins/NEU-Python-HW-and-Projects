Alex Perkins
CS 5001
Spring 2023

To answer the deep thinking question, I can see how building strings in these two tasks enables us to scale and adjust our definitions for the task needs as opposed to directly just typing out the output line by line which ultimately would save time and effort when planned and executed correctly.